// #include <algorithm>
// // #include <chrono>
// #include <cmath>
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <pcl/filters/passthrough.h>
// #include <nav_msgs/Odometry.h>//ros中的里程计信息头文件
// #include <opencv/cv.h>
// #include <pcl/filters/voxel_grid.h>
// #include <pcl/kdtree/kdtree_flann.h>
// #include <pcl/point_cloud.h>
// #include <pcl/point_types.h>
// #include <pcl_conversions/pcl_conversions.h>
// #include <ros/ros.h>
// #include <sensor_msgs/Imu.h>
// #include <sensor_msgs/PointCloud2.h>
// #include <tf/transform_broadcaster.h>
// #include <tf/transform_datatypes.h>

// double imuShiftXLast = 0, imuShiftYLast = 0, imuShiftZLast = 0, imuVeloXLast = 0, imuVeloYLast = 0, imuVeloZLast = 0, imuTimeLast = 1545218263.231441000;
// double imuTimeCur = 0, imuRollCur = 0, imuPitchCur = 0, imuYawCur = 0, imuAccXCur = 0, imuAccYCur = 0, imuAccZCur = 0, imuVeloXCur = 0, imuVeloYCur = 0, imuVeloZCur = 0;
// double imuShiftXCur = 0, imuShiftYCur = 0, imuShiftZCur = 0;
// double imuShiftXStart = 0, imuShiftYStart = 0, imuShiftZStart = 0, imuVeloXStart = 0, imuVeloYStart = 0, imuVeloZStart = 0, imuYawStart = 0, imuRollStart = 0,imuPitchStart = 0;
// double scanPeriod = 0.1;
// double timeDiff = 0;
// double pclTimeDiff = 0, pclTimeCur = 0, pclTimeLast = 1545218263.201441000;
// double imuShiftFromStartXCur = 0, imuShiftFromStartYCur = 0, imuShiftFromStartZCur = 0;
// double imuVeloFromStartXCur = 0, imuVeloFromStartYCur = 0, imuVeloFromStartZCur = 0;
// double accX = 0, accY = 0, accZ = 0;
// int i = 0, size = 0,q = 0;
// pcl::PCDWriter writer;
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_x (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_y (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_align (new pcl::PointCloud<pcl::PointXYZ>);
// // pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_align (new pcl::PointCloud<pcl::PointXYZRGBA>);
// pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_rgb (new pcl::PointCloud<pcl::PointXYZRGBA>);

// void VeloToStartIMU(){
//   imuVeloFromStartXCur = imuVeloXCur - imuVeloXStart;
//   imuVeloFromStartYCur = imuVeloYCur - imuVeloYStart;
//   imuVeloFromStartZCur = imuVeloZCur - imuVeloZStart;

//   double x_1 = cos(imuYawStart) * imuVeloFromStartXCur -
//              sin(imuYawStart) * imuVeloFromStartZCur;
//   double y_1 = imuVeloFromStartYCur;
//   double z_1 = sin(imuYawStart) * imuVeloFromStartXCur +
//              cos(imuYawStart) * imuVeloFromStartZCur;

//   double x_2 = x_1;
//   double y_2 = cos(imuPitchStart) * y_1 + sin(imuPitchStart) * x_1;
//   double z_2 = -sin(imuPitchStart) * y_1 + cos(imuPitchStart) * x_1;

//   imuVeloFromStartXCur = cos(imuRollStart) * x_2 + sin(imuRollStart) * y_2;
//   imuVeloFromStartYCur = -sin(imuRollStart) * x_2 + cos(imuRollStart) * y_2;
//   imuVeloFromStartZCur = z_2;
// }

// void ShiftToStartIMU(double pclTimeDiff){
//   imuShiftFromStartXCur =
//       imuShiftXCur - imuShiftXStart - imuVeloXStart * pclTimeDiff;
//   imuShiftFromStartYCur =
//       imuShiftYCur - imuShiftYStart - imuVeloYStart * pclTimeDiff;
//   imuShiftFromStartZCur =
//       imuShiftZCur - imuShiftZStart - imuVeloZStart * pclTimeDiff;//此处减去的部分或许还缺少加速度部分
//   double x11 = cos(imuYawStart) * imuShiftFromStartXCur -
//              sin(imuYawStart) * imuShiftFromStartZCur;
//   double y11 = imuShiftFromStartYCur;
//   double z11 = sin(imuYawStart) * imuShiftFromStartXCur +
//              cos(imuYawStart) * imuShiftFromStartZCur;

//   double x22 = x11;
//   double y22 = cos(imuPitchStart) * y11 + sin(imuPitchStart) * x11;
//   double z22 = -sin(imuPitchStart) * y11 + cos(imuPitchStart) * x11;

//   imuShiftFromStartXCur = cos(imuRollStart) * x22 + sin(imuRollStart) * y22;
//   imuShiftFromStartYCur = -sin(imuRollStart) * x22 + cos(imuRollStart) * y22;
//   imuShiftFromStartZCur = z22;
// }

// void imuHandler(const sensor_msgs::Imu::ConstPtr &imuIn) {
//   double roll1, pitch1, yaw1;
//   tf::Quaternion orientation;//四元数
//   tf::quaternionMsgToTF(imuIn->orientation, orientation);
//   tf::Matrix3x3(orientation).getRPY(roll1, pitch1, yaw1);
//   // double accY1 = imuIn->linear_acceleration.y - sin(roll1) * cos(pitch1) * 9.81;
//   // double accZ1 = imuIn->linear_acceleration.z - cos(roll1) * cos(pitch1) * 9.81;
//   // double accX1 = imuIn->linear_acceleration.x + sin(pitch1) * 9.81;
//     double accX1 = imuIn->linear_acceleration.y - sin(roll1) * cos(pitch1) * 9.81;
//   double accY1 = imuIn->linear_acceleration.z - cos(roll1) * cos(pitch1) * 9.81;
//   double accZ1 = imuIn->linear_acceleration.x + sin(pitch1) * 9.81;

//   imuTimeCur = imuIn->header.stamp.toSec();
//   timeDiff = imuTimeCur - imuTimeLast;
//   imuRollCur = roll1;
//   imuPitchCur = pitch1;
//   imuYawCur = yaw1;
//   imuAccXCur = accX1;
//   imuAccYCur = accY1;
//   imuAccZCur = accZ1;
  

//   double roll = imuRollCur;
//   double pitch = imuPitchCur;
//   double yaw = imuYawCur;
//   accX = imuAccXCur;
//   accY = imuAccYCur;
//   accZ = imuAccZCur;

//   double x_1 = cos(roll) * accX - sin(roll) * accY;
//   double y_1 = sin(roll) * accX + cos(roll) * accY;
//   double z_1 = accZ;

//   double x_2 = x_1;
//   double y_2 = cos(pitch) * y_1 - sin(pitch) * x_1;
//   double z_2 = sin(pitch) * y_1 + cos(pitch) * x_1;

//   accX = cos(yaw) * x_2 + sin(yaw) * z_2;
//   accY = y_2;
//   accZ = -sin(yaw) * x_2 + cos(yaw) * z_2;

//     imuShiftXCur = imuShiftXLast +
//                                 imuVeloXLast * timeDiff +
//                                 accX * timeDiff * timeDiff / 2;
//     imuShiftYCur = imuShiftYLast +
//                                 imuVeloYLast * timeDiff +
//                                 accY * timeDiff * timeDiff / 2;
//     imuShiftZCur = imuShiftZLast +
//                                 imuVeloZLast * timeDiff +
//                                 accZ * timeDiff * timeDiff / 2;
//     std::cout<<"  "<<imuShiftZCur<<std::endl;

//     imuVeloXCur = imuVeloXLast + accX * timeDiff;
//     imuVeloYCur = imuVeloYLast + accY * timeDiff;
//     imuVeloZCur = imuVeloZLast + accZ * timeDiff;

//     imuVeloXLast = imuVeloXCur;
//     imuVeloYLast = imuVeloYCur;
//     imuVeloZLast = imuVeloZCur;
//     imuShiftXLast = imuShiftXCur;
//     imuShiftYLast = imuShiftYCur;
//     imuShiftZLast = imuShiftZCur;
//     imuTimeLast = imuTimeCur;
// }

// void pclHandler(const sensor_msgs::PointCloud2ConstPtr &cloudIn){
//     pcl::fromROSMsg(*cloudIn, *cloud);
//     pclTimeCur = cloudIn->header.stamp.toSec();
//     pcl::PassThrough<pcl::PointXYZ> pass_x;
//     pass_x.setInputCloud(cloud);
//     pass_x.setFilterFieldName("x");
//     pass_x.setFilterLimits(2.0,3);
//     pass_x.filter(*cloud_x);

//     pcl::PassThrough<pcl::PointXYZ> pass_y;
//     pass_y.setInputCloud(cloud_x);
//     pass_y.setFilterFieldName("y");
//     pass_y.setFilterLimits(-2,-0.5);
//     pass_y.filter(*cloud_y);

//     pcl::PassThrough<pcl::PointXYZ> pass_z;
//     pass_z.setInputCloud(cloud_y);
//     pass_z.setFilterFieldName("z");
//     pass_z.setFilterLimits(-0.8,0.8);
//     pass_z.filter(*cloud);
//     pclTimeDiff = pclTimeCur - pclTimeLast;
//     pclTimeLast = pclTimeCur;
//         if (size == 0){
//       imuRollStart = imuRollCur;
//       imuPitchStart = imuPitchCur;
//       imuYawStart = imuYawCur;
//       imuShiftXStart = imuShiftXCur;
//       imuShiftYStart = imuShiftYCur;
//       imuShiftZStart = imuShiftZCur;
//       imuVeloXStart = imuVeloXCur;
//       imuVeloYStart = imuVeloYCur;
//       imuVeloZStart = imuVeloZCur;
//     }
//     ShiftToStartIMU(pclTimeDiff);
//     VeloToStartIMU();
//     size++;
//   for (size_t i=0; i<cloud->points.size();i++){
//     double x = cloud->points[i].y;
//     double y = cloud->points[i].z;
//     double z = cloud->points[i].x;
//   double x1 = cos(imuRollCur) * x - sin(imuRollCur) * y;
//   double y1 = sin(imuRollCur) * x + cos(imuRollCur) * y;
//   double z1 = z;

//   double x2 = x1;
//   double y2 = cos(imuPitchCur) * y1 - sin(imuPitchCur) * z1;
//   double z2 = sin(imuPitchCur) * y1 + cos(imuPitchCur) * z1;

//   double x3 = cos(imuYawCur) * x2 + sin(imuYawCur) * z2;
//   double y3 = y2;
//   double z3 = -sin(imuYawCur) * x2 + cos(imuYawCur) * z2;

//   double x4 = cos(imuYawStart) * x3 - sin(imuYawStart) * z3;
//   double y4 = y3;
//   double z4 = sin(imuYawStart) * x3 + cos(imuYawStart) * z3;

//   double x5 = x4;
//   double y5 = cos(imuPitchStart) * y4 + sin(imuPitchStart) * z4;
//   double z5 = -sin(imuPitchStart) * y4 + cos(imuPitchStart) * z4;
//     cloud->points[i].x =
//       cos(imuRollStart) * x5 + sin(imuRollStart) * y5 + imuShiftFromStartXCur;
//   cloud->points[i].y =
//       -sin(imuRollStart) * x5 + cos(imuRollStart) * y5 + imuShiftFromStartYCur;
//   cloud->points[i].z = z5 + imuShiftFromStartZCur;
//   }
//   cloud_align->width = cloud_align->points.size();
//   cloud_align->height = 1;
//   cloud_align->is_dense = false;
//   *cloud_align += *cloud;
//   std::stringstream s;
//   if (size % 5 == 0){
//     s<<"align_"<<q<<".pcd";
//      writer.write<pcl::PointXYZ>(s.str(),*cloud_align,false);
//     q++;
//     cloud_align->clear();
//     cloud_rgb->clear();
//   }
// }

// int main(int argc,char** argv){
//     ros::init (argc, argv,"read");
//     ros::NodeHandle nh;
//     ros::Subscriber sub_Imu = nh.subscribe<sensor_msgs::Imu>("/mti/sensor/imu",50,imuHandler);
//     ros::Subscriber sub_pcl = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points",10,pclHandler);
//     ros::spin();
//     return 0;
// }






//imu与rslidar结合进行点云配准

// #include <algorithm>
// // #include <chrono>
// #include <cmath>
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <vector>
// #include <pcl/filters/passthrough.h>
// #include <nav_msgs/Odometry.h>//ros中的里程计信息头文件
// #include <opencv/cv.h>
// #include <pcl/filters/voxel_grid.h>
// #include <pcl/kdtree/kdtree_flann.h>
// #include <pcl/point_cloud.h>
// #include <pcl/point_types.h>
// #include <pcl_conversions/pcl_conversions.h>
// #include <ros/ros.h>
// #include <sensor_msgs/Imu.h>
// #include <sensor_msgs/PointCloud2.h>
// #include <tf/transform_broadcaster.h>
// #include <tf/transform_datatypes.h>

// double imuShiftXLast = 0, imuShiftYLast = 0, imuShiftZLast = 0, imuVeloXLast = 0, imuVeloYLast = 0, imuVeloZLast = 0;
// // double imuTimeLast = 1545218263.231441000;
//  double imuTimeLast = 1545221875.131323000;
// double imuTimeCur = 0, imuRollCur = 0, imuPitchCur = 0, imuYawCur = 0, imuAccXCur = 0, imuAccYCur = 0, imuAccZCur = 0, imuVeloXCur = 0, imuVeloYCur = 0, imuVeloZCur = 0;
// double imuShiftXCur = 0, imuShiftYCur = 0, imuShiftZCur = 0;
// double imuShiftXStart = 0, imuShiftYStart = 0, imuShiftZStart = 0, imuVeloXStart = 0, imuVeloYStart = 0, imuVeloZStart = 0, imuYawStart = 0, imuRollStart = 0,imuPitchStart = 0;
// double scanPeriod = 0.1;
// double timeDiff = 0;
// double pclTimeDiff = 0, pclTimeCur = 0, pclTimeLast = 1545218263.201441000;
// double imuShiftFromStartXCur = 0, imuShiftFromStartYCur = 0, imuShiftFromStartZCur = 0;
// double imuVeloFromStartXCur = 0, imuVeloFromStartYCur = 0, imuVeloFromStartZCur = 0;
// double accX = 0, accY = 0, accZ = 0;
// int i = 0, size = 0,q = 0;
// pcl::PCDWriter writer;
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_x (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_y (new pcl::PointCloud<pcl::PointXYZ>);
// pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_align (new pcl::PointCloud<pcl::PointXYZ>);
// // pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_align (new pcl::PointCloud<pcl::PointXYZRGBA>);
// pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud_rgb (new pcl::PointCloud<pcl::PointXYZRGBA>);

// void VeloToStartIMU(){
//   imuVeloFromStartXCur = imuVeloXCur - imuVeloXStart;
//   imuVeloFromStartYCur = imuVeloYCur - imuVeloYStart;
//   imuVeloFromStartZCur = imuVeloZCur - imuVeloZStart;

//   double x_1 = cos(imuYawStart) * imuVeloFromStartXCur -
//              sin(imuYawStart) * imuVeloFromStartZCur;
//   double y_1 = imuVeloFromStartYCur;
//   double z_1 = sin(imuYawStart) * imuVeloFromStartXCur +
//              cos(imuYawStart) * imuVeloFromStartZCur;

//   double x_2 = x_1;
//   double y_2 = cos(imuPitchStart) * y_1 + sin(imuPitchStart) * x_1;
//   double z_2 = -sin(imuPitchStart) * y_1 + cos(imuPitchStart) * x_1;

//   imuVeloFromStartXCur = cos(imuRollStart) * x_2 + sin(imuRollStart) * y_2;
//   imuVeloFromStartYCur = -sin(imuRollStart) * x_2 + cos(imuRollStart) * y_2;
//   imuVeloFromStartZCur = z_2;
// }

// void ShiftToStartIMU(double pclTimeDiff){
//   double a = pclTimeDiff/timeDiff;
//   // imuShiftFromStartXCur = imuShiftXCur
//       // imuShiftXCur - imuShiftXStart - imuVeloXStart * pclTimeDiff;
//   // imuShiftFromStartYCur = imuShiftYCur
//       // imuShiftYCur - imuShiftYStart - imuVeloYStart * pclTimeDiff;
//   // imuShiftFromStartZCur = imuShiftZCur
//       // imuShiftZCur - imuShiftZStart - imuVeloZStart * pclTimeDiff;//此处减去的部分或许还缺少加速度部分
//   // double x11 = cos(imuYawStart) * imuShiftFromStartXCur -
//             //  sin(imuYawStart) * imuShiftFromStartZCur;
//   // double y11 = imuShiftFromStartYCur;
//   // double z11 = sin(imuYawStart) * imuShiftFromStartXCur +
//             //  cos(imuYawStart) * imuShiftFromStartZCur;

//   // double x22 = x11;
//   // double y22 = cos(imuPitchStart) * y11 + sin(imuPitchStart) * x11;
//   // double z22 = -sin(imuPitchStart) * y11 + cos(imuPitchStart) * x11;

//   // imuShiftFromStartXCur = cos(imuRollStart) * x22 + sin(imuRollStart) * y22;
//   // imuShiftFromStartYCur = -sin(imuRollStart) * x22 + cos(imuRollStart) * y22;
//   // imuShiftFromStartZCur = z22;
//   imuShiftFromStartXCur = imuShiftXCur * a;
//   imuShiftFromStartYCur = imuShiftYCur * a;
//   imuShiftFromStartZCur = imuShiftZCur * a;


// }

// void imuHandler(const sensor_msgs::Imu::ConstPtr &imuIn) {
//   double roll1, pitch1, yaw1;
//   tf::Quaternion orientation;//四元数
//   tf::quaternionMsgToTF(imuIn->orientation, orientation);
//   tf::Matrix3x3(orientation).getRPY(roll1, pitch1, yaw1);
//   // double accY1 = imuIn->linear_acceleration.y - sin(roll1) * cos(pitch1) * 9.81;
//   // double accZ1 = imuIn->linear_acceleration.z - cos(roll1) * cos(pitch1) * 9.81;
//   // double accX1 = imuIn->linear_acceleration.x + sin(pitch1) * 9.81;
//   double accY1 = imuIn->linear_acceleration.y - sin(roll1) * cos(pitch1) * 9.81;
//   double accZ1 = imuIn->linear_acceleration.z - cos(roll1) * cos(pitch1) * 9.81;
//   double accX1 = imuIn->linear_acceleration.x + sin(pitch1) * 9.81;//各轴的加速度考虑由于重力加速度带来的影响
//   imuTimeCur = imuIn->header.stamp.toSec();//获取imu的时间戳
//   timeDiff = imuTimeCur - imuTimeLast;
//   imuRollCur = roll1;
//   imuPitchCur = pitch1;
//   imuYawCur = yaw1;
//   imuAccXCur = accX1;
//   imuAccYCur = accY1;
//   imuAccZCur = accZ1;
  

//   double roll = imuRollCur;
//   double pitch = imuPitchCur;
//   double yaw = imuYawCur;
//   accX = imuAccXCur;
//   accY = imuAccYCur;
//   accZ = imuAccZCur;
//   //将加速度转化至世界坐标系
//   double x_1 = accX;
//   double y_1 = cos(roll) * accY - sin(roll) * accZ;
//   double z_1 = sin(roll) * accY + cos(roll) * accZ;

//   double x_2 = cos(pitch) * x_1 + sin(pitch) * z_1;
//   double y_2 = y_1;
//   double z_2 = -sin(pitch) * x_1 + cos(pitch) * z_1;

//   accX = cos(yaw) * x_2 - sin(yaw) * y_2;
//   accY = sin(yaw) * x_2 + cos(yaw) * y_2;
//   accZ = z_2;

// //计算位移，假设的两帧imu是匀加速运动，航向基本不变
//     imuShiftXCur = imuShiftXLast +
//                                 imuVeloXLast * timeDiff +
//                                 accX * timeDiff * timeDiff / 2;
//     imuShiftYCur = imuShiftYLast +
//                                 imuVeloYLast * timeDiff +
//                                 accY * timeDiff * timeDiff / 2;
//     imuShiftZCur = imuShiftZLast +
//                                 imuVeloZLast * timeDiff +
//                                 accZ * timeDiff * timeDiff / 2;
//       std::cout<<"  "<<imuShiftXCur<<"  "<<imuShiftYCur<<"  "<<imuShiftZCur<<std::endl;
//     // imuShiftXCur = imuVeloXLast * timeDiff +
//     //                             accX * timeDiff * timeDiff / 2;
//     // imuShiftYCur = imuVeloYLast * timeDiff +
//     //                             accY * timeDiff * timeDiff / 2;
//     // imuShiftZCur = imuVeloZLast * timeDiff +
//     //                             accZ * timeDiff * timeDiff / 2;
//     // double shiftX_1 = imuShiftXCur;
//     // double shiftY_1 = cos(roll) * imuShiftYCur - sin(roll) * imuShiftZCur;
//     // double shiftZ_1 = sin(roll) * imuShiftYCur + cos(roll) * imuShiftZCur;

//     // double shiftX_2 = cos(pitch) * shiftX_1 + sin(pitch) * shiftZ_1;
//     // double shiftY_2 = shiftY_1;
//     // double shiftZ_2 = -sin(pitch) * shiftX_1 + cos(pitch) * shiftZ_1;

//     // imuShiftXCur = cos(yaw) * shiftX_2 - sin(yaw) * shiftY_2;
//     // imuShiftYCur = sin(yaw) * shiftX_2 + cos(yaw) * shiftY_2;
//     // imuShiftZCur = shiftZ_2;

//     // std::cout<<"  "<<imuShiftZCur<<std::endl;
// //计算速度
//     imuVeloXCur = imuVeloXLast + accX * timeDiff;
//     imuVeloYCur = imuVeloYLast + accY * timeDiff;
//     imuVeloZCur = imuVeloZLast + accZ * timeDiff;

//     // double veloX_1 = imuVeloXCur;
//     // double veloY_1 = cos(roll) * imuVeloYCur - sin(roll) * imuVeloZCur;
//     // double veloZ_1 = sin(roll) * imuVeloYCur + cos(roll) * imuVeloZCur;

//     // double veloX_2 = cos(pitch) * veloX_1 + sin(pitch) * veloZ_1;
//     // double veloY_2 = shiftY_1;
//     // double veloZ_2 = -sin(pitch) * veloX_1 + cos(pitch) * veloZ_1;

//     // imuVeloXCur = cos(yaw) * veloX_2 - sin(yaw) * veloY_2;
//     // imuVeloYCur = sin(yaw) * veloX_2 + cos(yaw) * veloY_2;
//     // imuVeloZCur = shiftZ_2;

//     imuVeloXLast = imuVeloXCur;
//     imuVeloYLast = imuVeloYCur;
//     imuVeloZLast = imuVeloZCur;
//     imuShiftXLast = imuShiftXCur;
//     imuShiftYLast = imuShiftYCur;
//     imuShiftZLast = imuShiftZCur;

//     imuTimeLast = imuTimeCur;
// }

// void pclHandler(const sensor_msgs::PointCloud2ConstPtr &cloudIn){
//     pcl::fromROSMsg(*cloudIn, *cloud);
//     pclTimeCur = cloudIn->header.stamp.toSec();
//     // pcl::PassThrough<pcl::PointXYZ> pass_x;
//     // pass_x.setInputCloud(cloud);
//     // pass_x.setFilterFieldName("x");
//     // pass_x.setFilterLimits(2.0,3);
//     // pass_x.filter(*cloud_x);

//     // pcl::PassThrough<pcl::PointXYZ> pass_y;
//     // pass_y.setInputCloud(cloud_x);
//     // pass_y.setFilterFieldName("y");
//     // pass_y.setFilterLimits(-2,-0.5);
//     // pass_y.filter(*cloud_y);

//     // pcl::PassThrough<pcl::PointXYZ> pass_z;
//     // pass_z.setInputCloud(cloud_y);
//     // pass_z.setFilterFieldName("z");
//     // pass_z.setFilterLimits(-0.8,0.8);
//     // pass_z.filter(*cloud);
//     if ((pclTimeCur - imuTimeCur) < 0){
//      pclTimeDiff = pclTimeCur - imuTimeLast; 
//     }
//     else{
//       pclTimeDiff = timeDiff;
//     }
//     // pclTimeDiff = pclTimeCur - pclTimeLast;
//     pclTimeLast = pclTimeCur;
//         if (size == 0){
//       imuRollStart = imuRollCur;
//       imuPitchStart = imuPitchCur;
//       imuYawStart = imuYawCur;
//       imuShiftXStart = imuShiftXCur;
//       imuShiftYStart = imuShiftYCur;
//       imuShiftZStart = imuShiftZCur;
//       imuVeloXStart = imuVeloXCur;
//       imuVeloYStart = imuVeloYCur;
//       imuVeloZStart = imuVeloZCur;
//     }
//     ShiftToStartIMU(pclTimeDiff);
//     VeloToStartIMU();
//     size++;
//   for (size_t i=0; i<cloud->points.size();i++){
//   double x = cloud->points[i].x;
//   double y = cloud->points[i].y;
//   double z = cloud->points[i].z;

//   double x1 = x;
//   double y1 = cos(imuRollCur) * y - sin(imuRollCur) * z;
//   double z1 = sin(imuRollCur) * y + cos(imuRollCur) * z;
  
//   double x2 = cos(imuPitchCur) * x1 + sin(imuPitchCur) * z1;
//   double y2 = y1;
//   double z2 = -sin(imuPitchCur) * x1 + cos(imuPitchCur) * z1;

//   double x3 = cos(imuYawCur) * x2 - sin(imuYawCur) * y2;
//   double y3 = sin(imuYawCur) * x2 + cos(imuYawCur) * y2;
//   double z3 = z2;
  
//   double x4 = cos(imuYawCur) * x3 - sin(imuYawCur) * y3;
//   double y4 = sin(imuYawCur) * x3 + cos(imuYawCur) * y3;
//   double z4 = z3;

//   double x5 = cos(imuPitchCur) * x4 + sin(imuPitchCur) * z4;
//   double y5 = y4;
//   double z5 = -sin(imuPitchCur) * x4 + cos(imuPitchCur) * z4;

//   cloud->points[i].x = x5 + imuShiftFromStartXCur;
//   cloud->points[i].y = cos(imuRollCur) * y5 - sin(imuRollCur) * z5 + imuShiftFromStartYCur;
//   cloud->points[i].z = sin(imuRollCur) * y5 + cos(imuRollCur) * z5 + imuShiftFromStartZCur;
//   }
//   cloud_align->width = cloud_align->points.size();
//   cloud_align->height = 1;
//   cloud_align->is_dense = false;
//   *cloud_align += *cloud;
//   std::stringstream s;
//   if (size % 5 == 0){
//     s<<"align_"<<q<<".pcd";
//      writer.write<pcl::PointXYZ>(s.str(),*cloud_align,false);
//     q++;
//     cloud_align->clear();
//     cloud_rgb->clear();
//   }
// }

// int main(int argc,char** argv){
//     ros::init (argc, argv,"read");
//     ros::NodeHandle nh;
//     ros::Subscriber sub_Imu = nh.subscribe<sensor_msgs::Imu>("/mti/sensor/imu",50,imuHandler);
//     ros::Subscriber sub_pcl = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points",10,pclHandler);
//     ros::spin();
//     return 0;
// }







//皮新成去除地面点

#include <iostream>
#include <ros/ros.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h> // 可视化 
#include <pcl/filters/passthrough.h>
class cloudHandler
{
  public:
  cloudHandler()
  {
    pcl_sub = nh.subscribe("rslidar_points",10,&cloudHandler::cloudCB, this);
    pcl_pub = nh.advertise<sensor_msgs::PointCloud2>("read",10);
  }
  void cloudCB(const sensor_msgs::PointCloud2& input){
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr non_ground (new pcl::PointCloud<pcl::PointXYZ>);
    sensor_msgs::PointCloud2 output;

    pcl::fromROSMsg (input, *cloud);
    // double time = input.header.stamp.toSec();
    std::vector<int> indice;
    pcl::removeNaNFromPointCloud(*cloud,*cloud,indice);
    double a = -0.85;
    for (size_t i = 0; i < cloud->points.size(); i++){
      if (cloud->points[i].z - a > 0.15){
        non_ground->points.push_back(cloud->points[i]);
        non_ground->width = non_ground->points.size();
        non_ground->height = 1;
        non_ground->is_dense = false;
      }
    }
    std::cout<<"  "<<non_ground->points.size()<<std::endl;
    pcl::PCDWriter writer;
    writer.write<pcl::PointXYZ>("non_ground.pcd",*non_ground,false);

    pcl::toROSMsg(*non_ground,output);
    output.header.stamp  = input.header.stamp;
    output.header.frame_id = "rslidar";
    pcl_pub.publish(output);
  }
    protected:
    ros::NodeHandle nh;
    ros::Subscriber pcl_sub;
    ros::Publisher pcl_pub;
};
main (int argc, char** argv)
{
  ros::init (argc, argv, "read");
  // boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
  cloudHandler handler;
  ros::spin();

  return 0;
}